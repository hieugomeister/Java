To compile:
(1) Unzip this file [C:\SER215PROJ folder automatically created] - This may not be true on the Mac, 
    but the SER215PRO folder should be there.

(2) Rename the attached file ser215proj.jaw to ser215proj.jar and place it in SER215PROJ folder.


(3) Go to SER215PROJ folder and type the following command:
    jar xf ser215proj.jar

(4) Be sure to stay in the SER215PROJ folder, do the command below:
	javac *.java

To run:
(5) to run, do the following (stay in SER215PROJ) folder:
	java -cp . Playblackjack

	
